<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="less">
#app{
  width: 100%;
  height: 100%;
}
</style>
