export default {
    //购物车
    shopCart:{},
    userInfo:{}
}